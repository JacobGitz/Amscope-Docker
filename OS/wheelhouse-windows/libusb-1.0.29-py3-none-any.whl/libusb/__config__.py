from . import _config as _ ; _.make_config("libusb.cfg") ; del _
